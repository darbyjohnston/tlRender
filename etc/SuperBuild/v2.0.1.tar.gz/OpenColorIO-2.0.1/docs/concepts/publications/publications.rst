..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. _publications:

Publications
============

DigiPro 2020 **paper** "The ASWF takes OpenColorIO to the Next Level"
`Coming soon!`

DigiPro 2020 **video** "The ASWF takes OpenColorIO to the Next Level"
`Coming soon!`

`Cinematic Color <http://cinematiccolor.org/>`_
