## OCIO Homepage Setup / Dev

# Easy Setup (Hugo + Github Pages)

### What you need !!

### Step 1 : Fork or Clone repository - follow OCIO dev guidelines

Steps here

### Step 2 : Install Hugo

Insert Hugo info here

### Step 3 : Run locally

cd into homepage dir
hugo server --themesDir ../..
http://localhost:1313/

### Step 4 : Make changes! 

See them live locally.

### Step 5 : Submit a PR (back to OCIO guidelines)






