..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. autoclass:: PyOpenColorIO.ViewTransform
   :members:
   :undoc-members:
   :special-members: __init__, __str__
   :exclude-members: ViewTransformCategoryIterator

.. autoclass:: PyOpenColorIO.ViewTransform.ViewTransformCategoryIterator
   :special-members: __getitem__, __iter__, __len__, __next__
