..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. autoclass:: PyOpenColorIO.Transform
   :members:
   :undoc-members:
   :special-members: __init__, __str__
