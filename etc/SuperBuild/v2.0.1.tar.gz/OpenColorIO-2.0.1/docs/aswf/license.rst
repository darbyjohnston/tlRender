..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

.. _license:

License
=======

OpenColorIO is licensed under the BSD-3-Clause license. Contributions to the 
library should abide by that license unless otherwised approved by the OCIO 
TSC and ASWF Governing Board.

See `LICENSE 
<https://github.com/AcademySoftwareFoundation/OpenColorIO/blob/master/LICENSE>`__ 
on GitHub.

----

.. include:: ../LICENSE
