..
  SPDX-License-Identifier: CC-BY-4.0
  Copyright Contributors to the OpenColorIO Project.

Quick Start
===========

.. toctree::
   :caption: Quick Start

   for_artists
   for_config_authors
   for_devs
   for_contributors
   downloads
   installation


